import ga


print("All good.")
